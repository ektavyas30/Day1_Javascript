var n1=10,n2="10";

if(n1==n2){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}

if(n1===n2){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}

var n11=10,n22=10;

if(n11==n22){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}


if(n11===n22){
    document.write("<br/>Same.");
}
else
{
    document.write("<br/>Not Same.");
}
