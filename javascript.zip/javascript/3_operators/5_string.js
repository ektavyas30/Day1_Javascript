let s1 = "Ekta";
let s2 = "Vyas";
let s3 = s1 + " " + s2;
document.write(s3);