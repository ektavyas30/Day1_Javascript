const Human = {FirstName:"Ekta", LastName:"Vyas", age:27};
for (let H in Human) {
    document.write("<br/>"+H);
  }
document.write("<hr/>");
for (let H in Human) {
  document.write("<br/>"+Human[H]);
}